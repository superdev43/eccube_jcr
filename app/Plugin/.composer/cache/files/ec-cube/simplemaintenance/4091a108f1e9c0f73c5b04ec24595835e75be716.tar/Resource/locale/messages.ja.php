<?php
/**
 * Copyright(c) 2018 SYSTEM_KD
 * Date: 2018/07/29
 */
return [
    'simple_maintenance.config_title' => 'プラグイン設定',
    'simple_maintenance.config_sub_title' => 'メンテナンスプラグイン',
    'simple_maintenance.config_header' => 'メンテナンス設定',
    'simple_maintenance.config_mente_mode' => "メンテナンスモード",
    'simple_maintenance.config_admin_close_flg' => '管理者での閲覧',
    'simple_maintenance.config_page_html' => 'メンテナンス画面HTML',
    'simple_maintenance.config_back' => 'プラグイン一覧',
    'simple_maintenance.config_save' => '保存しました',
];
